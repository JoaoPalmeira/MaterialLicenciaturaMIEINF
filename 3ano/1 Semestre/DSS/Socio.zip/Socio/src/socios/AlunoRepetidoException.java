/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socios;

/**
 *
 * @author Daniel Vieira
 */
public class AlunoRepetidoException extends Exception{
    public  AlunoRepetidoException(){
        super();
    }
    
    public  AlunoRepetidoException(String message) {
        super(message);
    }
    
}
