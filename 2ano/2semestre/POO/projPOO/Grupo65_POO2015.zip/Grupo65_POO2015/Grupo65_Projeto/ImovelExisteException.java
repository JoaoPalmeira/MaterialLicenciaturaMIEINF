/**
 * Exceção para tratamento de erros.
 */
public class ImovelExisteException extends Exception
{
    public ImovelExisteException (String m) {
        super(m);
    }
}
