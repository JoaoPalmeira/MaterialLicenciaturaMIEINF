
/**
 * Interface usada para distinguir um tipo de Imóveis Habitáveis (Apartamento e Moradia).
 */
public interface Habitavel
{
    public void isHabitavel();
}
