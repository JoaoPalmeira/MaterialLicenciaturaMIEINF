
/**
 * Exceção para tratamento de erros.
 */
public class EstadoInvalidoException extends Exception {
    public EstadoInvalidoException(String m) {
        super(m);
    }
}
   