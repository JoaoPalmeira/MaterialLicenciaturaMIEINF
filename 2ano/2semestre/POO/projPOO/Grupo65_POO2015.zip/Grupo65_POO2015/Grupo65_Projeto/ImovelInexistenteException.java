/**
 * Exceção para tratamento de erros.
 */
public class ImovelInexistenteException extends Exception {
        public ImovelInexistenteException(String m) {
            super(m);
        }
}
