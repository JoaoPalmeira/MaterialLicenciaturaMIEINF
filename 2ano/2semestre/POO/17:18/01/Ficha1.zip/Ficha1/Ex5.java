
/**
 * Escreva a descrição da classe Ex5 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex5
{
  public static double media(double n1, double n2){
      return ((n1+n2)/2);
    }
}
