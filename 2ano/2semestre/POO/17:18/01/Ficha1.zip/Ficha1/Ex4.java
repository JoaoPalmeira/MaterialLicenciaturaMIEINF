
/**
 * Escreva a descrição da classe Ex4 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex4
{
    public double eurosParaLibras(double valor, double taxaConversao){
        return valor*taxaConversao;
    }
}
