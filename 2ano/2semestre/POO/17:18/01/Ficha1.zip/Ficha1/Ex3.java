
/**
 * Escreva a descrição da classe Ex3 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex3
{
    public String criaDescricaoConta(String nome, double saldo){
        return "Nome: " +nome+ "-> Saldo: "+saldo;
    }

}
