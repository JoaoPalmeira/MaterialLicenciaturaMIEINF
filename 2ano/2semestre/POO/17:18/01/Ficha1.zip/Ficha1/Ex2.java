import java.lang.String;
import java.util.Scanner;

/**
 * Escreva a descrição da classe Ex2 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex2
{
     public int maximoNumeros(int a, int b){
         if (a>=b) return a;
         else return b;
        }
}
