import java.util.Scanner;

public class Ex1
{
    public double celsiusParaFarenheit(double graus){
        graus += 37.5;
        return graus;
    }

}
