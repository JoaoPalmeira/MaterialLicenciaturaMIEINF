
/**
 * Escreva a descrição da classe Ex8 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex8
{
    private int leNumLim(String nome, int min, int max){
       
           
}
