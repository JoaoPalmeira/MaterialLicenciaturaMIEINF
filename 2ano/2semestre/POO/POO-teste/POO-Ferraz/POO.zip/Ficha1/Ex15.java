
/**
 * Escreva a descrição da classe Ex15 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex15
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private int x;

    /**
     * COnstrutor para objetos da classe Ex15
     */
    public Ex15()
    {
        // inicializa variáveis de instância
        x = 0;
    }

    /**
     * Exemplo de método - substitua este comentário pelo seu próprio
     * 
     * @param  y   exemplo de um parâmetro de método
     * @return     a soma de x com y 
     */
    public int sampleMethod(int y)
    {
        // ponha seu código aqui
        return x + y;
    }
}
