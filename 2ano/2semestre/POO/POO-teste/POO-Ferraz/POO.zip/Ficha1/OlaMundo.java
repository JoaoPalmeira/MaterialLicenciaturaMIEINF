
/**
 * Escreva a descrição da classe OlaMundo aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class OlaMundo
{

    public static void main(String[] args){
        System.out.println("Olá Mundo!");

}

}
