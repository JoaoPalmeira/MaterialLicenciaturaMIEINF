
/**
 * Escreva a descrição da classe Ex9 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex9
{
   public static String somaD(){
       
       
}





public static String main(String[] args)