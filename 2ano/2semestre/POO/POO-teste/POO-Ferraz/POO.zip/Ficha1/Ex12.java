
/**
 * Escreva a descrição da classe Ex12 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex12
{
    
}
