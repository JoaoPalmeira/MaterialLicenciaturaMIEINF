
/**
 * Escreva a descrição da classe Ex11 aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ex11
{
    
    
}
