
/**
 * Escreva a descrição da interface CartaoPontos aqui.
 * 
 * @author (seu nome) 
 * @version (número da versão ou data)
 */

public interface CartaoPontos
{
    public void setPontos(int pontos);
    public int getPontos();
}
