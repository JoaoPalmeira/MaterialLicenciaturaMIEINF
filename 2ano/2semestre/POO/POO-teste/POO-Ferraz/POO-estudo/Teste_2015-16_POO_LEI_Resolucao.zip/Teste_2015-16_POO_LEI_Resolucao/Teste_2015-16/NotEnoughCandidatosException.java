public class NotEnoughCandidatosException extends Exception
{
    public NotEnoughCandidatosException(){
        super();
    }
    
    public NotEnoughCandidatosException(String s){
        super(s);
    }
}
