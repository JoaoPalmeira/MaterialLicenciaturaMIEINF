public class CandidatoException extends Exception{
    public CandidatoException(){
        super();
    }
    
    public CandidatoException(String s){
        super(s);
    }
}