public class NoMoreCandidatosException extends Exception{
    public NoMoreCandidatosException(){
        super();
    }
    
    public NoMoreCandidatosException(String s){
        super(s);
    }
}
