import java.util.*;

public abstract class Parque implements IParque
{
    public void entra(String cartao, String matricula) throws SemPermissaoException{
    }
}
