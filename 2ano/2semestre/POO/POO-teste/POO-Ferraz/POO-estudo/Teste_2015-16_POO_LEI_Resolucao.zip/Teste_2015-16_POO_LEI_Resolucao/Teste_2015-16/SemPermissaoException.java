public class SemPermissaoException extends Exception{
    public SemPermissaoException(){
        super();
    }
    
    public SemPermissaoException(String s){
        super(s);
    }
}