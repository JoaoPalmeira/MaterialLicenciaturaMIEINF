
/**
 * Write a description of class TesteListaPaises here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TesteListaPaises
{
    public static void main(String[] args){
       ListaPaises p= new ListaPaises();
       FichaPais p1,p2,p3;
       p1.adicionar("Portugal","Europa",1000000); 
       p2.adicionar("Espanha","Europa",4700000);
       p3.adicionar("França","Europa",6600000);
       p.adicionar("Holanda","Europa",1700000);
       p.adicionar("Brasil","America do Sul",20000000);
      int n= p.numPaises();
      int e= p.numPaises("Europa");
      int f= p.numPaisesF("Europa");
      FichaPais g = p.getFicha("Portugal");
     // FichaPais h= p.getFichaF("Portugal");
      System.out.println("Nº total de Países: "+n);
      System.out.println("-----Iteradores externos--------");
      System.out.println("Nº Países europeus: "+e);
      System.out.println("Ficha->: "+g);
      System.out.println("-----Iteradores internos--------");
      System.out.println("Nº Países europeus: "+f);
      //System.out.println("Ficha->: "+h);
    }
}
