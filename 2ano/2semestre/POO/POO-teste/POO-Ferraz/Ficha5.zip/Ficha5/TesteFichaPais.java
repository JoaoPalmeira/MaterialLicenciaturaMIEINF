
/**
 * Write a description of class TesteFichaPais here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TesteFichaPais
{
    public static void main(String[] args){
       FichaPais p1,p2,p3;
       p1= new FichaPais("Portugal","Europa",1000000); 
       p2= new FichaPais("Espanha","Europa",4700000);
       p3= new FichaPais("França","Europa",6600000);
       
       System.out.println(p1);
       System.out.println(p2);
       System.out.println(p3);
    }
}
