#include <sys/times.h>
#include <limits.h>

long ticks_times();
double start_times();
double read_times(double *);
double print_times();


