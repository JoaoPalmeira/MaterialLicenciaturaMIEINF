

/******************************************************************
 *
 *    MODULE benchtimes.c:
 *
 *          long ticks_timer()
 *          double start_times()
 *          double read_times(double *)
 *          double print_times()
 *
 ******************************************************************/

#include "benchtimes.h"

clock_t start;
struct tms tmsstart;


/******************************************************************
 *    Return granularity of the timers (Ticks per Second)
 ******************************************************************/

long ticks_times()
{
   return CLK_TCK;
}


double start_times()
{
   start=times(&tmsstart);
   return((double)start/CLK_TCK);
}



/******************************************************************
 *    result = time elapsed; store in *totaltimes sum of
 *                           user+sys time of process & children
 ******************************************************************/
double read_times(double *totaltimes)
{
   clock_t   now;
   struct tms tmsnow;
   
   if ((now = times(&tmsnow)) == -1)
	return (double)now;
   else {
        *totaltimes = ((double)(tmsnow.tms_utime - tmsstart.tms_utime +
	          tmsnow.tms_stime - tmsstart.tms_stime +
	          tmsnow.tms_cutime - tmsstart.tms_cutime +
	          tmsnow.tms_cstime - tmsstart.tms_cstime))/CLK_TCK;
	return ((double)(now - start))/CLK_TCK;
   }
}

/******************************************************************
 *   print elapsed  and  user+sys time of process & children
 ******************************************************************/
double print_times()
{
   clock_t   now;
   struct tms tmsnow;
   double time = -1;
   
   if ((now = times(&tmsnow)) != -1) {
	time = ((double)(now - start))/CLK_TCK;
        printf("User+sys =%7.3f, Elapsed =%7.3f",
	((double)(tmsnow.tms_utime - tmsstart.tms_utime +
	          tmsnow.tms_stime - tmsstart.tms_stime +
	          tmsnow.tms_cutime - tmsstart.tms_cutime +
	          tmsnow.tms_cstime - tmsstart.tms_cstime))/CLK_TCK, time);
   }
   return time;
}




double print_rtimes()
{
   clock_t   now;
   struct tms tmsnow;
   double time = -1;
   
   if ((now = times(&tmsnow)) != -1) {
	time = ((double)(now - start))/CLK_TCK;
        printf("Real =%7.3f", time);
	return time;
   }else
	return -1;
}

