#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>



int main(){
	


_exit(1);
}
