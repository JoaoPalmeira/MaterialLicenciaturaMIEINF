#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

void mycat(int k, int fildes)
{
    void *c = malloc(k);
    while(read(fildes, c, k))
        write(1, c, k);
    printf("\n");
}

int main(int argc, char * argv[])
{
    int k = atoi(argv[1]);
    int fildes;
    if(argc == 2) 
        fildes = 0;
    else 
        fildes = open(argv[2], O_RDONLY);
    if(fildes==-1)
    {
        perror("Não abriu o ficheiro");
        exit(-1);
    }
    mycat(k,fildes);
    close(fildes);
    return 0;
}