#include <sys/signal.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>




