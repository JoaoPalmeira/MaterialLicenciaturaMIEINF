#include <stdio.h>
#include <stdlib.h>
#include "ex5.c"
#define BUF_SIZE 1024
#define NUM_LENGTH 20

int itostr(char * buf, int k){
	/* retorna o n de chars escritos */
	int i = 1, biggestPower;
	buf[0] = '\t';
	for(biggestPower = 1; biggestPower <= k; biggestPower *= 10)
		;
	biggestPower /= 10;
	for( ; biggestPower > 1; biggestPower /= 10, i++){
        buf[i] = '0' + k/biggestPower;
        k %= biggestPower;
	}
	buf[i++] = '0' + k;
    buf[i++] = ' ';
    return i;
}

void nl(int fildesIN, int fildesOUT){
    char buf[BUF_SIZE];
    //char num[NUM_LENGTH];

    int i, c = 1;
    ssize_t r;

    /* ao ler o numero para o mesmo buffer,reduzo para metade as chamadas a write */ 
    while ((i = itostr(buf,c)) &&  
           (r = readln(fildesIN, (void *) buf + i, BUF_SIZE - i)))
    {
    	//i = itostr(num, c);
    	//write(fildesOUT, num, i);
		write(fildesOUT, buf,r+i);
    	c++;
    }
    buf[0] = '\n';
    write(fildesOUT, buf, 1);
}

int main(int argc, char * argv[]){
	int fildesIN = 0, fildesOUT = 1;
	if(argc > 1) 
		fildesIN = open(argv[1], O_RDONLY);
	/*if(argc > 2) 
		fildesOUT = open(argv[2], O_RDONLY|O_WRONLY| O_CREAT);*/
    nl(fildesIN, fildesOUT);
    return 0;
}