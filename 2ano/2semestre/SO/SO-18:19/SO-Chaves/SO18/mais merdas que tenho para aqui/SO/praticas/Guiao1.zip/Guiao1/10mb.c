#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

void mb10(int fildes)
{
    char c = 'a';
    int i = 10 * 1000 * 1024;
    while(i)
    {
         write(fildes, &c, 1);
         i--;
    }
    c = EOF;
    write(fildes, &c, 1);
}

int main(int argc, char * argv[])
{
    int fildes;
    if(argc == 1) 
        fildes = 1;
    else 
        fildes = open(argv[1], O_WRONLY | O_CREAT, 0x1C0);
    if(fildes==-1)
    {
        perror("Não abriu o ficheiro");
        exit(-1);
    }
    mb10(fildes);
    close(fildes);
    return 0;
}