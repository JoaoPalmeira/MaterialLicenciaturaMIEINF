#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

ssize_t readln(int fildes, void * buf, size_t nbyte){
    int lidos = 0, i, j;
    static int tamanho_buffer, inicio, fim;
    static char * buffer = NULL;
    ssize_t ret;
    
    char * buf1 = buf;
    
    if(!buffer){
        lidos = read(fildes, buf1, nbyte);
        for(i = 0; i < lidos && buf1[i] != '\n'; i++)
           ;
        ret = i; 
        if(i != lidos){
           buffer = malloc(lidos - i);
           inicio = 0; 
           fim = lidos - i;
           for(j = 0; j < fim; j++, i++)
               buffer[j] = buf1[i];
         }
     } else {
         for(i = 0; lidos<nbyte && inicio<fim; i++, inicio++){
             lidos++;
             buf1[i] = buffer[inicio];
             if(buffer[inicio] == '\n') break;
         }
         if(inicio == fim){ 
             free(buffer);
             buffer = NULL;
             if (lidos < nbyte){
                 nbyte = read(fildes, buf1 + lidos, nbyte - lidos) + lidos;
                 for(i = lidos; i < nbyte && buf1[i] != '\n'; i++)
                     ;
                 ret = i;
                 if(i != nbyte){
                      buffer = (char *) malloc(nbyte - i);
                      inicio = 0;
                      fim = nbyte - i;
                      for (j = 0; i < nbyte; i++, j++){
                           buffer[j] = buf1[i];
                      }
                  }
               }
           }
        }
      return ret;
}

int main(){
    char bla[100];
    bla[99] = '\0';
    int k =readln(0,bla,99);
    printf("%d: %s",k,  bla);
    
    k =readln(0,bla,99);
    printf("%d: %s",k,  bla);

    return 0;
}

