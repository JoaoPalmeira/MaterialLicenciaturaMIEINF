#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

int main()
{
    char c;
    int r=1;
    while(r)
    {
    	r=read(0,&c,1);
    	if(r==-1)
    	{
    		perror("Erro no read!!!");
    		exit(-1);
    	}
        write(1,&c,1);
    }
    return 0;
}