#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

ssize_t readln(int fildes, void *buf, size_t nbyte)
{
	char c;
	ssize_t i;
	for(i=0;read(fildes,&c,1)==1 && i<nbyte;i++)
	{
        ((char*)buf)[i]=c;
        if(c=='\n')
        	break;
	}
	return i;
}

int main(int argc, char * argv[])
{
    int k = atoi(argv[1]);
    int fildes;
    if(argc == 2) 
        fildes = 0;
    else 
        fildes = open(argv[2], O_RDONLY);
    if(fildes==-1)
    {
        perror("Não abriu o ficheiro");
        exit(-1);
    }
    readln(fildes,,k);
    close(fildes);
    return 0;
}