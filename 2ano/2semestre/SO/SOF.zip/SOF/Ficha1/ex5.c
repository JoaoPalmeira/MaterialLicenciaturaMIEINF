#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

int readln(int fd, char* buffer, int max){
	int i=1;
	int n;
	n=read(fd, buffer, 1);
	while(i<max && buffer[i-1]!='\n'){
		n=read(fd,buffer+i,1);
		i++;	
	}
	buffer[i]=0;	
}

int main(int agrc, char ** argv){
	char buffer[100];
	int fd;
	fd=open("textoEx5.txt", O_RDONLY);

	readln(fd, buffer, 100);
	printf("Linha lida: %s", buffer);
	close(fd);
	return 0;
}
