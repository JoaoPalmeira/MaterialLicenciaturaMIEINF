import Test.QuickCheck
import Data.Maybe
import Data.List


oneof :: [Gen a] -> Gen a
oneof l = do x <- choose (0,length l-1)
             l!!x

elements1 :: [a] -> Gen a
elements1 l = do x <- choose (0,length l-2)
                 return (l!!x)

frequency1::[(Int,Gen a)] -> Gen a
frequency1 l = do let t = sum (map fst l)
                  x <- choose(1,t)
                  escolher x l

escolher :: Int -> [(Int,Gen a)] -> Gen a
escolher  x ((y,ys):t) | (x<=y) = ys
                       | otherwise = escolher (x-1) t

data Frac = Frac { num :: Integer , den :: Integer}
    deriving (Eq,Show)

instance Arbitrary Frac where
    arbitrary = do { n <- arbitrary
                   ; d <- arbitrary
                   ; return (Frac n d)
                   }

--sampleFrac:: IO ()
--sampleFrac = sample (arbitrary :: Frac)

instance Num Frac where
    (+) = addFrac
    (*) = mulFrac
    abs = absFrac
    signum = signumFrac
    fromInteger = fromIntegerFrac

addFrac :: Frac -> Frac -> Frac
addFrac (Frac n1 d1) (Frac n2 d2) | d1==d2 = Frac (n1+n2) d1
                                  | otherwise = Frac (n1*d2+n2*d1) (d1*d2)

mulFrac :: Frac -> Frac -> Frac
mulFrac (Frac n1 d1) (Frac n2 d2) = Frac (n1*n2) (d1*d2)

absFrac :: Frac -> Frac
absFrac (Frac n1 d1) = Frac (abs n1) (abs d1)

signumFrac :: Frac -> Frac
signumFrac i = i

fromIntegerFrac :: Integer -> Frac
fromIntegerFrac i = Frac i 1

prop_FracA (Frac n d) = isOne (mulFrac (Frac n d) (Frac d n))

isOne (Frac n d) = n==d

prop_FracB f = f+f == f*(Frac 2 1)

data Nota = Faltou
          | Reprovou
          | Nota Int
          deriving (Eq,Show)

data Aluno = Aluno {numero ::  Int
                 , nome :: String
                 , nota :: Nota 
                 } deriving (Eq,Show)

type Turma = [Aluno]

instance Arbitrary Nota where
    arbitrary = frequency [ (1, return Faltou)
                          , (2, return Reprovou)
                          , (5, do n <- arbitrary `suchThat` notaValida
                                   return (Nota n))
                          ]
notaValida i = i>=10 && i<=20

instance Arbitrary Aluno where
    arbitrary = do n <- choose (1,80000)
                   no <- elements ["Ana","To","Be"]
                   nt <- arbitrary
                   return (Aluno n no nt)

procura :: Int -> Turma -> Maybe Nota
procura _ [] = Nothing
procura n ((Aluno n1 _ nt):t) | n==n1 = Just nt
                              | otherwise = procura n t

update :: Aluno -> Turma -> Turma
update a [] = a:[]
update (Aluno n no nt) ((h@(Aluno n1 no1 nt1)):t) | n == n1 = ((Aluno n no nt):t)
                                                  | otherwise = h:(update (Aluno n no nt) t)

prop_Aluno1 :: Aluno -> Turma -> Bool
prop_Aluno1 a@(Aluno n no nt) t = fromJust (procura n (update a t)) == nt

data BTree a = Empty
             | Node a (BTree a) (BTree a)
             deriving (Eq,Show)

instance Arbitrary a=>Arbitrary (BTree a) where
    arbitrary = sized aux
        where  aux 0 = empty
               aux n = frequency [(1,empty)
                                 ,(4,node n)]
               empty = return Empty
               node n = do v <- arbitrary
                           l <- aux (n`div`2)
                           r <- aux (n`div`2)
                           return (Node v l r)
