--
-- Projecto CP 2015/16
--
-- O projecto consiste em desenvolver testes para o módulo Graph.hs
-- (para grafos orientados e não pesados).
-- Mais concretamente, o projecto consiste em 3 tarefas que são descritas abaixo.
-- O prazo para entrega é o dia 3 de Abril. Cada grupo deve enviar apenas
-- o módulo de testes (este módulo) por email para calculodeprogramas@gmail.com
-- O nome do ficheiro deve identificar os números dos 2 alunos do grupo (numero1_numero2.hs).
-- Certifiquem-se que o módulo de testes desenvolvido compila correctamente antes
-- de submeter. O módulo Graph.hs não deve ser alterado.
-- Os 2 alunos do grupo devem também indentificar-se nos comentários abaixo.
--
-- Aluno 1:
-- Número:
-- Nome:
-- Curso:
--
-- Aluno 2
-- Número:
-- Nome:
-- Curso:
--


module Main where

import Graph
import Test.HUnit hiding (path)
import Test.QuickCheck
import Data.Set as Set

--
-- Teste unitário
--
    
g1 :: Graph Int
g1 = Graph {nodes = fromList [1],
            edges = fromList [Edge 1 1]
           }

--
--Grafos para testes
--

g2 :: Graph String
g2 = Graph {nodes = fromList ["Barcelos","Braga","VilaVerde","Guimaraes","PovoaLanhoso"],
            edges = fromList [Edge "Barcelos" "Braga",Edge "Braga" "Barcelos",Edge "Braga" "VilaVerde",Edge "Braga" "Guimaraes",Edge "Guimaraes" "PovoaLanhoso",Edge "PovoaLanhoso" "VilaVerde"]
           }

--DAG
g3 :: Graph Int
g3 = Graph {nodes = fromList [1,2,3,4],
            edges = fromList [Edge 1 2,Edge 2 3,Edge 3 4,Edge 2 4]
           }

--NOT DAG
g4 :: Graph Int
g4 = Graph {nodes = fromList [1,2,3,4],
            edges = fromList [Edge 1 2,Edge 2 3,Edge 3 4,Edge 2 4,Edge 4 1]
           }

--NOT Valid, edge inexistente
g5 :: Graph Int
g5 = Graph {nodes = fromList [1,2,3,4],
            edges = fromList [Edge 1 2,Edge 1 5,Edge 2 3,Edge 3 4,Edge 2 4,Edge 4 1]
           }

--NOT Valid, edge inexistente
g6 :: Graph Int
g6 = Graph {nodes = fromList [1,2,3,4],
            edges = fromList [Edge 1 2,Edge 5 4,Edge 2 3,Edge 3 4,Edge 2 4,Edge 4 1]
           }

--g7 é subgrafo de g2
g7 :: Graph String
g7 = Graph {nodes = fromList ["Barcelos","Braga","VilaVerde","Guimaraes","PovoaLanhoso"],
            edges = fromList [Edge "Barcelos" "Braga",Edge "Braga" "Barcelos"]
           }      
--g7 NÃO É subgrafo de g2
g8 :: Graph String
g8 = Graph {nodes = fromList ["Braga","VilaVerde"],
            edges = fromList [Edge "Braga" "VilaVerde",Edge "VilaVerde" "Braga"]
           }           

--transposta da g4
g9 :: Graph Int
g9 = Graph {nodes = fromList [1,2,3,4],
            edges = fromList [Edge 2 1,Edge 3 2,Edge 4 3,Edge 4 2,Edge 1 4]
           }

g10 :: Graph Int
g10 = Graph {nodes = fromList [1,5],
            edges = fromList [Edge 1 5]
           }         

g11 :: Graph Int
g11 = Graph {nodes = fromList [1,2,3,4,5],
            edges = fromList [Edge 1 5,Edge 1 2,Edge 2 3,Edge 3 4,Edge 2 4]
           }   
p1::Graph.Path String
p1 =[Edge "Barcelos" "Braga",Edge "Braga" "VilaVerde"] 

p2::Graph.Path String
p2=[Edge "Barcelos" "Braga",Edge "Braga" "Barcelos",Edge "Braga" "VilaVerde"] 

p3::Graph.Path String
p3=[Edge "Barcelos" "Braga",Edge "Braga" "PovoaLanhoso"] 

p4::Graph.Path String
p4=[Edge "Barcelos" "Braga",Edge "Braga" "Lisboa"] 

-- Um exemplo de um teste unitário.
test_adj :: Test
test_adj =TestList[adj g1 1 ~?= fromList [Edge 1 1],adj g2 "Braga" ~?= fromList [Edge "Braga" "Barcelos",Edge "Braga" "VilaVerde",Edge "Braga" "Guimaraes"],adj g3 1 ~?= fromList [Edge 1 2],adj g4 2 ~?= fromList [Edge 2 3,Edge 2 4]]

--
-- Tarefa 1
--
-- Defina testes unitários para todas as funções do módulo Graph,
-- tentando obter o máximo de cobertura de expressões, condições, etc.
--

test_swap::Test
test_swap= swap (Edge 1 0)~?= Edge 0 1      

test_isEmpty::Test
test_isEmpty=TestList[Graph.isEmpty Graph.empty~?=True,Graph.isEmpty g1~?=False,Graph.isEmpty g2~?=False,Graph.isEmpty g3~?=False,Graph.isEmpty g4~?=False]

--todo:"e se não há mais do que uma aresta entre dois pares de nós."
test_isValid::Test
test_isValid=TestList[isValid g1~?=True,isValid g2~?=True,isValid g3~?=True,isValid g4~?=True,isValid g5~?=False,isValid g6~?=False]

test_isDAG::Test
test_isDAG=TestList[isDAG g1~?=False,isDAG g2~?=False,isDAG g3~?=True,isDAG g4~?=False]

--TODO:isForst(perguntar stor)

test_isSubgraphOf::Test
test_isSubgraphOf=TestList[isSubgraphOf g7 g2~?=True,isSubgraphOf g8 g2~?=False]

test_transpose::Test
test_transpose=TestList[transpose g4~?=g9]

test_union::Test
test_union= TestList[Graph.union g3 g4~?=g4,Graph.union g2 g2~?=g2,Graph.union g3 g10~?=g11]

--ver bft	

test_reachable::Test
test_reachable=TestList[reachable g2 "VilaVerde"~?=fromList["VilaVerde"],reachable g2 "Braga"~?=fromList["Barcelos","Braga","VilaVerde","Guimaraes","PovoaLanhoso"],reachable g3 1~?=fromList[1,2,3,4],reachable g3 2~?=fromList[2,3,4]]

test_isPathOf::Test
test_isPathOf= TestList[isPathOf p1 g2 ~?=True,isPathOf p2 g2 ~?=False,isPathOf p3 g2 ~?=False,isPathOf p4 g2 ~?=False]

test_path::Test
test_path= TestList[path g2 "Barcelos" "PovoaLanhoso"~?=(Just [Edge {source = "Barcelos", target = "Braga"},Edge {source = "Braga", target = "Guimaraes"},Edge {source = "Guimaraes", target = "PovoaLanhoso"}]),path g2 "PovoaLanhoso" "Barcelos"~?=Nothing]


main = runTestTT $ TestList [test_adj,test_swap,test_isEmpty,test_isValid,test_isDAG,test_isSubgraphOf,test_transpose,test_union,test_reachable,test_isPathOf,test_path]


--
-- Teste aleatório
--

--
-- Tarefa 2
--
-- A instância de Arbitrary para grafos definida abaixo gera grafos
-- com muito poucas arestas, como se pode constatar testando a
-- propriedade prop_valid.
-- Defina uma instância de Arbitrary menos enviesada.
-- Este problema ainda é mais grave nos geradores dag e forest que
-- têm como objectivo gerar, respectivamente, grafos que satisfazem
-- os predicados isDag e isForest. Estes geradores serão necessários
-- para testar propriedades sobre estas classes de grafos.
-- Melhore a implementação destes geradores por forma a serem menos enviesados.
--

-- Instância de Arbitrary para arestas
instance Arbitrary v => Arbitrary (Edge v) where
    arbitrary = do s <- arbitrary
                   t <- arbitrary
                   return $ Edge {source = s, target = t}

instance (Ord v, Arbitrary v) => Arbitrary (Graph v) where
    arbitrary = aux `suchThat` isValid
        where aux = do ns <- arbitrary
                       es <- arbitrary
                       return $ Graph {nodes = fromList ns, edges = fromList es}
 
prop_valid :: Graph Int -> Property
prop_valid g = collect (length (edges g)) $ isValid g

-- Gerador de DAGs
dag :: (Ord v, Arbitrary v) => Gen (DAG v)
dag = arbitrary `suchThat` isDAG

prop_dag :: Property
prop_dag = forAll (dag :: Gen (DAG Int)) $ \g -> collect (length (edges g)) $ isDAG g

-- Gerador de florestas
forest :: (Ord v, Arbitrary v) => Gen (Forest v)
forest = arbitrary `suchThat` isForest

prop_forest :: Property
prop_forest = forAll (forest :: Gen (Forest Int)) $ \g -> collect (length (edges g)) $ isForest g

--
-- Tarefa 3
--
-- Defina propriedades QuickCheck para testar todas as funções
-- do módulo Graph.
--

-- Exemplo de uma propriedade QuickCheck para testar a função adj          
prop_adj :: Graph Int -> Property
prop_adj g = forAll (elements $ elems $ nodes g) $ \v -> adj g v `isSubsetOf` edges g





-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




Tarefa 2, o que fiz foi gerar os nodos aleatoriamente,
e a partir dos nodos, criar vértices. Cria antes de
mais nada uma função auxiliar na qual na lista d
nodos cria um vértice com dois nodos aleatórios.
Para criares o gerador de vértices, das a lista
de nodos, e a quantidade de vértices a criar.

Tarefa 3, dependes da 2 para fazer os testes,
mas se te ajuda, podes fazer quickchecks com
bools.

--1

instance (Ord v, Arbitrary v) => Arbitrary (Graph v) where 
  arbitrary = do ns <- Set.fromList <$> liftA2 (++) (replicateM 10 arbitrary) arbitrary
              let ns' = map reverse $ drop 2 $ inits $ Set.toList ns
              es <- sublistOf ns' >>= mapM (\(f:ts) -> Edge f <$> elements ts)
      return $ Graph ns (Set.fromList es) 




    ------- ou -------

--2
--a)

instance Arbitrary Cell where
   arbitrary = do Positive x <- arbitrary
                  Positive y <- arbitrary
     return $ Cell x y


   ----mas mais bonito----
--b)
instance Arbitrary Cell where
   arbitrary = Cell <$> pos <*> pos
      where pos = getPositive <$> arbitrary  -- getPositive requires QC >= 2.5

a 1ª maneira é mesmo para o nosso trabalho, mas nao ponhas la assim, senao levas um fraude valente xd
a 2 é uma maneira geral, que da para qualquer coisa, tem de se adaptar para grafos




-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



-- Tarefa 2
instance Arbitrary v => Arbitrary (Edge v) where
    arbitrary = do s <- arbitrary
                   t <- arbitrary
                   return $ Edge {source = s, target = t}
 
instance (Ord v, Arbitrary v) => Arbitrary (Graph v) where
    arbitrary = aux1 `suchThat` isValid
        where aux1 = do ns <- arbitrary
                        return $ Graph {nodes = fromList ns, edges = fromList $ aux2 ns}
              aux2 [] = []
              aux2 [x] = []
              aux2 (x:y:t) = [Edge x y] ++ aux2 t
 

--aux :: Set v -> Int -> Gen (Edge v)
--aux v n = elems v 

--aux2 :: Set v -> Gen (Edge v)
--aux2 v = do { v <- elements v }




-- Tarefa 3
 
-- swap
prop_swap_double :: Edge Int -> Bool
prop_swap_double e = (swap $ swap e) == e
 
-- empty
    -- Acho que não é preciso testar
 
-- isEmpty
prop_isEmpty_numNodes :: Graph Int -> Property
prop_isEmpty_numNodes g = isEmpty g ==> (length $ nodes g) == 0
 
-- transpose
prop_transpose_double :: Graph Int -> Bool
prop_transpose_double g = (transpose $ transpose g) == g




prop_isEmpty_numNodes :: Graph Int -> Property
prop_isEmpty_numNodes g = isEmpty g ==> (length $ nodes g) == 0
 
prop_isDAG_transpose :: Graph Int -> Property
prop_isDAG_transpose g = isDAG g ==> (isDAG $ transpose g)
 
prop_union_nodes :: Graph Int -> Graph Int -> Bool
prop_union_nodes g g' = (fromList $ (elems $ nodes $ g) ++ (elems $ nodes $ g')) == (fromList $ elems $ nodes $ Graph.union g g')
 
prop_union_reflex :: Graph Int -> Bool
prop_union_reflex g = g == Graph.union g g