{-# LANGUAGE MultiParamTypeClasses, TypeFamilies #-}

module Pointfree where

import Prelude hiding (unlines,replicate,abs,uncurry,const,sum,foldr,map,length,LT)

--
-- Combinadores
--
    
-- Produtos

infix 6 /\
(/\) :: (a -> b) -> (a -> c) -> a -> (b,c)
(/\) f g x = (f x, g x)

pi1 :: (a,b) -> a
pi1 = fst

pi2 :: (a,b) -> b
pi2 = snd

infix 7  ><
(><) :: (a -> b) -> (c -> d) -> (a,c) -> (b,d)
f >< g = f . fst /\ g . snd

-- Somas

i1 :: a -> Either a b
i1 = Left

i2 :: b -> Either a b
i2 = Right

infix 4 \/
(\/) :: (b -> a) -> (c -> a) -> Either b c -> a
(\/) = either

infix 5 -|-
(-|-) :: (a -> b) -> (c -> d) -> Either a c -> Either b d
f -|- g = i1 . f \/ i2 . g

-- Guarda

infix ?

(?) :: (a -> Bool) -> a -> Either a a
p ? x = if p x then Left x else Right x

-- Exponenciais

ap :: (a -> b, a) -> b
ap (f,x) = f x

uncurry :: (a -> b -> c) -> ((a,b) -> c)
uncurry f = ap . (f >< id)
           
-- Unidade

(!) :: a -> ()
(!) _ = ()

-- Catas genericos

class Functor f => FunctorOf a f where
    inn :: f a -> a
    cata :: (f b -> b) -> a -> b
    cata f = f . fmap (cata f) . out
    out :: a -> f a
    out = cata (fmap inn)
            
-- Listas

inL :: Either () (a,[a]) -> [a]
inL = const [] \/ uncurry (:)

cataL :: (Either () (a,b) -> b) -> [a] -> b
cataL f []    = f (Left ())
cataL f (h:t) = f (Right (h, cataL f t))

newtype L a r = L {unL :: Either () (a,r)}
    deriving (Eq, Show)

instance Functor (L a) where
    fmap f = L . (id -|- id >< f) . unL

instance a ~ b => FunctorOf [a] (L b) where
    inn = inL . unL
    cata f = cataL (f . L)
             
-- Leaf trees

data LTree a = Leaf a | Fork (LTree a) (LTree a)
               deriving (Eq,Show)

inLT :: Either a (LTree a, LTree a) -> LTree a
inLT = Leaf \/ uncurry Fork

cataLT :: (Either a (b,b) -> b) -> LTree a -> b
cataLT g (Leaf x)   = g (Left x)
cataLT g (Fork l r) = g (Right (cataLT g l, cataLT g r))

newtype LT a r = LT {unLT :: Either a (r,r)}
    deriving (Eq,Show)

instance Functor (LT a) where
    fmap f = LT . (id -|- f >< f) . unLT

instance a ~ b => FunctorOf (LTree a) (LT a) where
    inn = inLT . unLT
    cata f = cataLT (f . LT)
                      
-- Naturais

data Nat = Zero | Succ Nat
           deriving (Eq,Show)

inN :: Either () Nat -> Nat
inN = const Zero \/ Succ

cataN :: (Either () b -> b) -> Nat -> b
cataN g Zero     = g (Left ())
cataN g (Succ n) = g (Right (cataN g n))

newtype N r = N {unN :: Either () r}
    deriving (Eq,Show)

instance Functor N where
    fmap f = N . (id -|- f) . unN

instance FunctorOf Nat N where
    inn = inN . unN
    cata f = cataN (f . N)
            
--
-- Exemplos teóricas
--

unlines :: [String] -> String
unlines = concat . map (++"\n")

evenpos :: [a] -> [a]
evenpos = map snd . filter (even . fst) . zip [0..]

average :: [Float] -> Float
average = uncurry (/) . (sum /\ fromIntegral . length)

swap :: (a,b) -> (b,a)
swap = pi2 /\ pi1

assocr :: ((a,b),c) -> (a,(b,c))
assocr = (pi1 . pi1) /\ (pi2 >< id)

replicate :: Int -> a -> [a]
replicate = curry (uncurry take . (id >< repeat))

abs :: (Num a,Ord a) => a -> a
abs = (negate \/ id) . ((<0)?)

coswap :: Either a b -> Either b a
coswap = i2 \/ i1

coassocr :: Either a (Either b c) -> Either (Either a b) c
coassocr = (i1 . i1) \/ (i2 -|- id)

undistr :: Either (a,b) (a,c) -> (a, Either b c)
undistr = (pi1 \/ pi1) /\ (pi2 -|- pi2)

distl :: (Either a b, c) -> Either (a,c) (b,c)
distl = uncurry (curry i1 \/ curry i2)

const :: a -> (() -> a)
const = curry pi1

sum :: Num a => [a] -> a
sum = cataL (const 0 \/ uncurry (+))

foldr :: (a -> b -> b) -> b -> [a] -> b
foldr f z = cataL (const z \/ uncurry f)

map :: (a -> b) -> [a] -> [b]
map f = cataL (inL . (id -|- f >< id))

length :: [a] -> Int
length = cataL ((const 0 \/ (1+) . pi2))

faverage :: [Float] -> Float
faverage = uncurry (/) . (id >< fromIntegral) . sumLength
    where sumLength = cataL (((const 0 \/ uncurry (+)) . (id -|- id >< pi1)) /\ ((const 0 \/ (1+) . pi2) . (id -|- id >< pi2)))

sumLT :: Num a => LTree a -> a
sumLT = cataLT (id \/ uncurry (+))

mirror :: LTree a -> LTree a
mirror = cataLT (inLT . (id -|- swap))

replica :: a -> Nat -> [a]
replica x = cataN (inL . (id -|- const x . (!) /\ id))

len :: [a] -> Nat
len = cataL (inN . (id -|- pi2))